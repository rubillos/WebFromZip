var oneColumn = false;

$.fn.killClass = function(className) {
	this.removeClass(className);
	
	if (this.attr("class")=="") {
		this.attr("class", null);
	}
}
	
function extractItem(name) {
	let $item = $(name);
	$item.detach();
	$item.killClass('hidden');
	$item.removeAttr('id');
	return $item;
}

var $blankRow = extractItem(".blankrow");
var $emptyRow = extractItem("#emptyrow");

function hasNotch() {
	if (CSS.supports('padding-bottom: constant(safe-area-inset-bottom)')) {
		let div = document.createElement('div');
		div.style.paddingBottom = 'constant(safe-area-inset-bottom)';
		document.body.appendChild(div);
		let calculatedPadding = parseInt(window.getComputedStyle(div).paddingBottom, 10);
		document.body.removeChild(div);
		if (calculatedPadding > 0) {
			return true;
		}
	}
	return false;
}

var sidebarShowing = true;

function hideSidebar(force) {
	if (oneColumn && sidebarShowing) {
		$("#sidecover").addClass("hidden");
		sidebarShowing = false;
		if (force) {
			$("#sidebar").css( { left: "-240px" } );
			$("#searchcontrols").css( { opacity: 0 } );
			$("#searchcontrols").addClass("hidden");
			$(".sidebutton").css( { opacity: 0 } );
			$(".sidebutton").addClass("hidden");
			$("#leftcolumndiv").css( { opacity: 1.0 } );
		}
		else {
			$("#sidebar").animate( { left: "-240px" } );
			$("#searchcontrols").animate( { opacity: 0 }, 400, function() {
				$("#searchcontrols").addClass("hidden");
			} );
			$(".sidebutton").animate( { opacity: 0 }, 400, function() {
				$(".sidebutton").addClass("hidden");
			} );
			$("#leftcolumndiv").animate( { opacity: 1.0 } );
		}
	}
}

function showSidebar() {
	if (oneColumn && !sidebarShowing) {
		$("#sidecover").killClass("hidden");
		$("#searchcontrols").killClass("hidden");
		$(".sidebutton").killClass("hidden");
		sidebarShowing = true;
		$("#sidebar").animate( { left: "0px" }, 200 );
		$(".sidebutton").animate( { opacity: 1.0 }, 100 );
		$("#searchcontrols").animate( { opacity: 1.0 }, 100 );
		$("#leftcolumndiv").animate( { opacity: 0.4 }, 200 );
	}
}

function toggleSidebar() {
	if (oneColumn) {
		if (sidebarShowing) {
			hideSidebar(false);
		}
		else {
			showSidebar();
		}
	}
}

function toggleSideBarIfVisible(event) {
	if (event.target==event.currentTarget || $(event.target).css("opacity")==0.0) {
		toggleSidebar(); 
	}
}

var didTouchMove;
$.fn.fastTouch = function(onStart, func) {
	if (oneColumn) {
		this.each(function() {
			let $this = $(this);
			$this.on("touchstart", function(e) {
				didTouchMove = false;
				if (onStart) { func.call($this[0], e); }
			}).on("touchmove", function() {
				didTouchMove = true;
			}).on("touchend", function(e) {
				if (!onStart && !didTouchMove) { func.call($this[0], e); }
			});
		});
	}
	else {
		this.each(function() {
			let $this = $(this);
			$this.click(function(e) { func.call($this[0], e); } );
		});
	}
	return this;
};

if (screen.width < 700) {
	oneColumn = true;

	let yscale = {"transform": "scaleY(1.5)", "display": "inline-block"};
	let rowFont = { "font-size": 18, "line-height": "32px" };
	let lowerFont = { "font-size": "10px", "line-height": "12px" };
	let tagFont = { "font-size": "18px", "line-height": "22px" };

	$('head').append('<meta name="viewport" content="width=566, viewport-fit=cover">');
	$("#rightcolumndiv").remove();
	$("#travelheader").remove();
	$("#travelspacer").killClass("hidden");

	$("#topdiv").css( { "min-width": "560px" } );
	$("#menubutton").killClass("hidden");
	$("#sidebar").css( { width: "280px"} );
	$(".sidebutton").css( { width: "240px"} );
	$emptyRow.find(".rowdate").css( { width: 138 } ).css(rowFont);
	$emptyRow.find(".rowtitle").css( { width: 370 } ).css(rowFont);
	$emptyRow.find(".rowdate").css(yscale);
	$emptyRow.find(".itemlink").css(yscale);
	$("#sidebar").css( { position:"absolute", "z-index":100 } );
	$(".sidebartext").css( { "font-size": "20px", "line-height": "21px" } );
	$("#sidebar").css( { "background-size": "100% auto" } );
	$(".sidebutton").css( { "margin-bottom": "20px", "margin-top": "10px" } );
	$(".searchdiv").css( { "width": "240px", "font-size": "24px", "line-height": "26px" } );
	$(".searchtext").css( { "font-size": "18px" } );
	$("#searchclear").css( { "font-size": "18px", "padding-top": "8px" } );
	hideSidebar(true);
	$("#columnwrapper").css( { "left": "40px" } );
	$("#leftcolumndiv").css( { "width": "520px" } );
	$("#count").css(lowerFont);
	$("#stats").css(lowerFont);
	$("#copyright").css(lowerFont);
	$("#searchtags").css(tagFont);
	
	$("#menubutton").fastTouch(true, function() { toggleSidebar(); });
	$("#sidecover").fastTouch(true, function(e) { e.preventDefault(); hideSidebar(false); });
	$("#sidebar").fastTouch(false, function(e) { toggleSideBarIfVisible(e); });
	$(".sidebutton").click(function() { hideSidebar(false); });		
}
else {
	$('head').append('<meta name="viewport" content="width=940">');
}

var $iconNew = extractItem("#iconnew");
var $iconDive = extractItem("#icondive");
var $iconCamera = extractItem("#iconcamera");
var $iconStar = extractItem("#iconstar");

var currentSearchTerm;
var numberOfItems = 0;

$("#sidebar").height($(window).height());
$("body").killClass('hidden');

$(function(){
	Array.prototype.pushUnique = function (item){
		if(jQuery.inArray(item, this) == -1) {
			this.push(item);
			return true;
		}
		return false;
	}

	var yearIndex = 0;
	var monthIndex = 1;
	var dayIndex = 2;
	var columnIndex = 3;
	var titleIndex = 4;
	var pathIndex = 5;
	var flagsIndex = 6;
	var latLonIndex = 7;
	var statsIndex = 8;

	var keywords = ["dive", "movie", "pw", "swim", "penguins", "keynote", "drone", "napa", "europe", "africa",
					"asia", "family", "aggressor", "ken", "seattle", "boston", "cruise", "atlantis", "tapas",
					"rvlife", "narrated", "helicopter", "wedding", "21st", "bray" ];

	var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	var rowsPerPass = 50;
	var travel = { year:null, div:$("#travelcolumn"), rows:null, old:false };
	var local = { year:null, div:$("#localcolumn"), rows:null, old:false };
	var searchFocus = false;
	var mouseInKeywords = false;
	var keyX = 0, keyY = 0;
	var allRows = null;
	var numberOfFlights = 0;
	var numberOfRVMiles = 0;
	var numberOfRVCamps = 0
	var allRVCamps = [];
	var allCountries = [];
	var allStates = [];
	var flightMiles = 0;
	var cruiseCount = 0;

	var timeouts = [];
	var messageName = "zero-timeout-message";

	function zeroTimeout(fn) {
		timeouts.push(fn);
		window.postMessage(messageName, "*");
	}

	function handleMessage(event) {
		if (event.source===window && event.data===messageName) {
			event.stopPropagation();
			if (timeouts.length > 0) {
				var fn = timeouts.shift();
				fn();
			}
		}
	}

	window.addEventListener("message", handleMessage, true);

	var notched = false;
	function updateMargins() {
		let currentNotch = hasNotch();
		if (notched != currentNotch) {
			if (currentNotch) {
				$("#topheading").css("padding-right", "5px");
				$("#sidebar").css("padding-left", "10px");
				$("#sidebar").css("width", "150px");
			}
			else {
				$("#topheading").css("padding-right", "");
				$("#sidebar").css("padding-left", "");
				$("#sidebar").css("width", "160px");
			}
			notched = currentNotch;
		}
	}

	$(window).resize(function() {
		updateMargins();
	});
	updateMargins();
		
	function addRow(row){
		let items = row.split("\t");
		let year = items[yearIndex];
		let flags = (items.length > flagsIndex) ? items[flagsIndex] : "";
		let date = "";
		let yearPrefix = "";
		let isTravel = (items[columnIndex].charAt(0) == "T");
		let column = (oneColumn || isTravel) ? travel:local;
		let title = items[titleIndex];
		let subGroup = items[columnIndex].substring(1);

		if (column.rows == null) {
			column.rows = document.createDocumentFragment();
		}

		if (flags.includes("cruise")) {
			cruiseCount++;
		}
		
		let haveFlight = false;
		
		if (items[monthIndex] != "") {
			date = months[parseInt(items[monthIndex])-1];
		 
			if (items[dayIndex] != "") {
				date += "-" + items[dayIndex];
			}
		}
		
		if (column.year == null || column.year != year) {
			if (column.year != null) {
				column.rows.appendChild($blankRow.clone()[0]);
			}
			yearPrefix = "<strong>" + year + "</strong> ";
			date = yearPrefix + date;
			column.year = year;
		}
		
		if (items.length>statsIndex) {
			let stats = items[statsIndex];
			
			if (stats.length > 0) {
				let statParts = stats.split(",");
				
				for (part of statParts) {
					let components = part.split(":");
					
					if (components.length > 1) {
						if (components[0]=="f") {
							numberOfFlights += parseInt(components[1], 10);
							haveFlight = true;
						}
						else if (components[0]=="rvc") {
							let camps = components[1].split(";");
							
							for (camp of camps) {
								allRVCamps.pushUnique(camp);
							}
							numberOfRVCamps += camps.length;
						}
						else if (components[0]=="rvm") {
							numberOfRVMiles += parseInt(components[1], 10);
						}
						else if (components[0]=="c") {
							let countries = components[1].split(";");
							
							for (country of countries) {
								allCountries.pushUnique(country);
							}
						}
						else if (components[0]=="s") {
							let states = components[1].split(";");
							
							for (state of states) {
								allStates.pushUnique(state);
							}
						}
						else if (components[0]=="n" && currentSearchTerm=="narrated" && flags.includes("narrated")) {
							numberOfItems += parseInt(components[1], 10)-1;
						}
					}
				}
			}
		}
		
		if (haveFlight && items.length>latLonIndex && !flags.includes("middle")) {
			let destinations = items[latLonIndex].split(";");
			
			if (destinations.length > 0) {
				let reversed = flags.includes("cruise") || flags.includes("rvlife") || flags.includes("cardrive");
				let maxDist = 0;
				let curIndex = 0;
				
				for (destination of destinations) {
					let latLon = destination.split(",");
					
					if (latLon.length >= 2) {
						let curDist, curLat, curLon;
						
						if (reversed) {
							curLat = latLon[1];
							curLon = latLon[0];
						}
						else {
							curLat = latLon[0];
							curLon = latLon[1];
						}
						curDist = getDistanceFromSFInMiles(curLat, curLon);
						
						maxDist = Math.max(maxDist, curDist);
					}
					curIndex++;
				}
				
				if (!flags.includes("beginning") && !flags.includes("finish")) {
					maxDist *= 2;
				}
				flightMiles += maxDist;
				
				// date = yearPrefix + Math.floor(maxDist);
			}
		}
		
		if (allCountries.length == 0) {
			allCountries.push("US");
		}

		let $newRow = $emptyRow.clone();
		let $href = $newRow.find(".itemlink");

		$newRow.find(".rowdate").html(date);

		let link = items[pathIndex];
		if (link.length>0) {
			if (!link.includes("/")) {
				if (isTravel) {
					link = "travel/" + link;
				}
				else {
					link = "Local/" + link;
				}
			}
			if (!link.includes(".htm") && !link.endsWith("/"))
			{
				link = link + "/index.html";
			}
			$href.attr('href', link);
		}

		if (flags.length>0) {
			if (flags.includes("dive")) { $iconDive.clone().appendTo($href.parent()); }
			if (flags.includes("star")) { $iconStar.clone().appendTo($href.parent()); }
			if (flags.includes("pw")) { $iconCamera.clone().appendTo($href.parent()); }
		}

		$href.html(title);
		
		if (subGroup.length > 0) {
			$newRow.attr("subgroup", subGroup);
		}
		
		column.rows.appendChild($newRow[0]);
	}

	function updateSearch() {
		if (currentSearchTerm!=undefined && currentSearchTerm.length>0) {
			$('#searchclear').killClass("hidden");
			$('#searchtags').addClass("hidden");
			$('#searchdiv2').addClass("hidden");
		}
		else if (searchFocus) {
			$('#searchclear').addClass("hidden");
			$('#searchtags').killClass("hidden");
			$('#searchdiv2').addClass("hidden");
		}
		else {
			if (mouseInKeywords) {
				let clicked = document.elementFromPoint(keyX, keyY);
				if (clicked != null) {
					let $clicked = $(clicked);
					if ($clicked.attr('class') == "keyword") {
						if (oneColumn) {
							document.location.search = "search=" + $clicked.html();
						}
						else {
							$("#searchtext").val($clicked.html());
							$("#searchtext").select();
							addRowsWithSearchTerm(allRows, $clicked.html());
							zeroTimeout(function() {
								$("#searchtext").focus();
							});
						}
					}
				}
			}
			$('#searchclear').addClass("hidden");
			$('#searchtags').addClass("hidden");
			$('#searchdiv2').killClass("hidden");
		}
	}

	function moveToDiv(info) {
		if (info.rows != null) {
			info.div[0].appendChild(info.rows);
			info.rows = null;
		}
	}

	const one_degree = Math.PI/180;
	function deg2rad(deg) {
		return deg * one_degree;
	}
	const SFLat = deg2rad(37.783333);
	const SFLon = deg2rad(-122.416667);
	const cosSFLat = Math.cos(SFLat);

	function getDistanceFromSFInMiles(lat1, lon1) {
		if (lat1.includes("D")) {
			lat1 = lat1.substring(1);
		}

		const R = 3959; // Radius of the earth in miles
		lat1 = deg2rad(lat1);
		lon1 = deg2rad(lon1);
		let sindLat2 = Math.sin((SFLat-lat1)/2);
		let sindLon2 = Math.sin((SFLon-lon1)/2);
		let a = sindLat2 * sindLat2 + Math.cos(lat1) * cosSFLat * sindLon2 * sindLon2;
		let c = 2 * Math.asin(Math.sqrt(a))
		let d = R * c;
		return d;
	}
	
	function prependToTitle($div, str) {
		let $link = $div.find(".itemlink");
		
		if ($link != undefined) {
			$link.before(str);
		}
	}
	
	function showSubGroups(column) {
		let itemList = column.div.children();
		let lastRow = itemList.length;
		let lastSubGroup = undefined; 
		let $lastRow = undefined;
		let groupCount = 0;
		let $row;
		let match = false;
		let $connector = $("<div style='position:absolute; top:11px;'>│</div>");
		
		for (let i=0; i<=lastRow; i++) {
			$row = (i<lastRow) ? $(itemList[i]) : undefined;
			
			if ($row == undefined || !$row.hasClass("blankrow")) {
				let subGroup = ($row != undefined) ? $row.attr("subgroup") : undefined;
				match = false;
				
				if (groupCount > 1 && subGroup != lastSubGroup && $lastRow != undefined) {
					prependToTitle($lastRow, "└ ");
					groupCount = 0;
				}
				
				if (subGroup != undefined && subGroup != lastSubGroup) {
					groupCount = 1;
				}
				else if (subGroup != undefined && subGroup == lastSubGroup) {
					if (groupCount == 1) {
						let $prefix = $("<span style='position:relative;'>┌ </span>");
						$prefix.append($connector.clone());
						prependToTitle($lastRow, $prefix);
					}
					else if (groupCount > 1) {
						let $prefix = $("<span style='position:relative;'>│ </span>");
						$prefix.append($connector.clone());
						prependToTitle($lastRow, $prefix);
					}
					groupCount = groupCount + 1;
					match = true;
				}
				
				lastSubGroup = subGroup;
				$lastRow = $row;
			}
		}
	}
	
	function formattedNumber(number) {
		let suffix = "";
		
		if (number > 1000000) {
			number = Math.round(number/100000) / 10;
			suffix = "M";
		}
		else if (number > 20000) {
			number = Math.round(number/1000);
			suffix = "K";
		}
		else if (number > 1000) {
			number = Math.round(number/100) / 10;
			suffix = "K";
		}
		
		return number.toLocaleString() + suffix;
	
	}
	
	function joinTextItems(list) {
		let sorted = list.toSorted((a, b) => a.localeCompare(b, undefined, {sensitivity: 'case'}));
		let joined = sorted.join(",").replaceAll(" ", "&nbsp").replaceAll(",", ", ");
		return joined;
	}
	
	function makeTextWithTooltip(text, tooltip) {
		return "<span class='tooltip'>" + text + "<span class='tooltiptext'>" + tooltip + "</span></span>";
	}
	
	function addRows(rows, startRow){
		let rowCount = rows.length;
		let lastRow = Math.min(startRow+rowsPerPass, rowCount);

		for (let i=startRow; i<lastRow; i++) {
			addRow(rows[i]);
			numberOfItems++;
		}

		moveToDiv(travel);
		moveToDiv(local);

		if (lastRow < rowCount) {
			zeroTimeout(function() {
				addRows(rows, lastRow);
			});
		}
		else {
			if (currentSearchTerm!=undefined && currentSearchTerm.length>0) {
				$("#count").html('"' + currentSearchTerm + '" - ' + numberOfItems + ' item' + ((numberOfItems > 1) ? 's':'') + ' found');
			}
			else {
				$("#count").html("" + numberOfItems + ' entries');
			}
			$("#count").killClass("hidden");
			
			let statString = "";
			let doBreak = (oneColumn && (allRVCamps.length >0) && (numberOfFlights > 0)) || (oneColumn && (allCountries.length>1) && (allRVCamps.length==0));
			
			if (allCountries.length == 1 && allCountries[0] != "US") {
				statString = "1 country";
			}
			else if (allCountries.length > 1) {
				statString = makeTextWithTooltip(allCountries.length + " countries", joinTextItems(allCountries));
			}
			if (allStates.length > 0) {
				if (statString.length > 0) {
					statString += " / "
				}
				if (allStates.length == 1) {
					statString = statString + makeTextWithTooltip("1 state", joinTextItems(allStates));
				}
				else {
					statString = statString + makeTextWithTooltip(allStates.length + " states", joinTextItems(allStates));
				}
			}
			if (allRVCamps.length > 0) {
				if (statString.length > 0) {
					statString += "<br>"
				}
				if (allRVCamps.length == 1) {
					statString = statString + "1 campground";
				}
				else {
					statString = statString + makeTextWithTooltip(numberOfRVCamps + " stays at " + allRVCamps.length + " campgrounds", joinTextItems(allRVCamps));
				}
			}
			if (numberOfRVMiles > 0) {
				if (statString.length > 0) {
					statString += " / "
				}
				statString = statString + formattedNumber(numberOfRVMiles) + " RV miles";
			}
			if (cruiseCount > 0) {
				if (statString.length > 0) {
					if (doBreak) {
						statString += "<br>"
						doBreak = false;
					}
					else {
						statString += " / "
					}
				}
				if (cruiseCount == 1) {
					statString = statString + "1 cruise";
				}
				else {
					statString = statString + cruiseCount + " cruises";
				}
			}
			if (numberOfFlights > 0) {
				if (statString.length > 0) {
					if (doBreak) {
						statString += "<br>"
						doBreak = false;
					}
					else {
						statString += " / "
					}
				}
				if (numberOfFlights == 1) {
					statString = statString + "1 flight";
				}
				else {
					statString = statString + numberOfFlights + " flights";
				}
			}
			if (flightMiles > 1000) {
				if (statString.length > 0) {
					statString += " / "
				}

				statString = statString + makeTextWithTooltip(formattedNumber(flightMiles) + " air miles", Math.round(flightMiles).toLocaleString() + " miles");
			}
			if (statString.length > 0) {
				$("#stats").html(statString);
				$("#stats").killClass("hidden");
			}
			
			showSubGroups(travel);
			showSubGroups(local);
						
			$("#copyright").killClass("hidden");
			$("#sidebar").height(Math.max($(window).height(), $("#columnwrapper").height()+20));
		}
	}

	function addRowsWithSearchTerm(rows, searchTerm) {
		$("#copyright").addClass("hidden");
		$("#count").addClass("hidden");
		$("#stats").addClass("hidden");
		local.div.children().remove();
		travel.div.children().remove();
		local.year = null;
		travel.year = null;
		currentSearchTerm = searchTerm;
		numberOfItems = 0;
		numberOfFlights = 0;
		numberOfRVMiles = 0;
		numberOfRVCamps = 0;
		allCountries = [];
		allStates = [];
		allRVCamps = [];
		flightMiles = 0;
		cruiseCount = 0;
		
		if (searchTerm.includes("fbclid")) {
			searchTerm = "";
		}

		if (searchTerm!=undefined && searchTerm.length>0) {
			searchTerm = decodeURI(searchTerm).toLowerCase();

			let rowsToShow = [];
			let numeric = (searchTerm >= 1990 && searchTerm <= 2050);
			const regex = /^(\d{4})?-(\d{4})?$/;
			let rangeInfo = searchTerm.match(regex);
			let haveRange = (rangeInfo != undefined);
			let haveKeyword = (keywords.indexOf(searchTerm) >= 0);
			let haveFlights = (searchTerm == 'flights');
			let haveLocal = (searchTerm == "local");
			let haveTravel = (searchTerm == "travel");
			
			if (haveRange) {
				if (rangeInfo[1] == undefined) rangeInfo[1] = 1900;
				if (rangeInfo[2] == undefined) rangeInfo[2] = 2100;
			}

			rows.forEach(function(row) {
				let items = row.split("\t");
				let flags = (items.length > flagsIndex) ? items[flagsIndex] : "";
				let include = false;
				let itemCountries = [];
				let itemStates = [];

				if (items.length>statsIndex) {
					let stats = items[statsIndex];
					
					if (stats.length > 0) {
						let statParts = stats.split(",");
						
						for (part of statParts) {
							let components = part.split(":");
							
							if (components.length > 1) {
								if (components[0]=="c") {
									let countries = components[1].split(";");
									
									for (country of countries) {
										itemCountries.pushUnique(country.toLowerCase());
									}
								}
								else if (components[0]=="s") {
									let states = components[1].split(";");
									
									for (state of states) {
										itemStates.pushUnique(state.toLowerCase());
									}
								}
							}
						}
					}
				}

				if (haveLocal) {
					include = (items[columnIndex].charAt(0) == "L");
				}
				else if (haveTravel) {
					include = (items[columnIndex].charAt(0) == "T");
				}
				else if (haveFlights && items.length>statsIndex) {
					for (part of items[statsIndex].split(",")) {
						let components = part.split(":");
						
						if (components.length > 1 && components[0]=="f") {
							include = true;
						}
					}
				}
				else if (haveKeyword) {
					include = flags.includes(searchTerm);
				}
				else if (haveRange) {
					let itemYear = items[yearIndex];
					include = itemYear >= rangeInfo[1] && itemYear <= rangeInfo[2];
				}
				else if (numeric) {
					include = items[yearIndex] == searchTerm;
				}
				else if (itemCountries.includes(searchTerm)) {
					include = true;
				}
				else if (itemStates.includes(searchTerm)) {
					include = true;
				}
				else {
					include = items[titleIndex].toLowerCase().includes(searchTerm);
				}
				
				if (include) {
					rowsToShow.push(row);
				}
			});
			addRows(rowsToShow, 0);
		}
		else {
			addRows(rows, 0);
		}
		updateSearch();
		if ("ontouchstart" in document.documentElement) {
	 		$("a").css("touch-action", "manipulation");
		}
		$(".sidebutton").fastTouch(false, function(e) {
			e.preventDefault();
			$(this).find("a").each(function() { document.location.href = this.href; });
		}).css("cursor", "pointer");
	}

	if (document.location.href.includes("Users/mediaserver") && $(window).width()>950) {
		let zoom = (Math.min(1600, $(window).width()) / 950) * 100;
		$('body').css("zoom", zoom+"%");
	}

	$.get( "links.txt?" + Math.floor(Math.random() * 10000), function(data) {
		allRows = data.split(/\r\n|\r|\n/g);
	
		let $copyright = $("#copyright > a");
		let currentDate = new Date();

		$copyright.html($copyright.html().replace("9999", currentDate.getFullYear()));

		let query = document.location.search.substr(1);
		let searchTerm = "";
		
		if (query.includes("=")) {
			let terms = query.split("&");
			
			for (term of terms) {
				let parts = term.split("=");
				
				if (parts[0] == "search") {
					searchTerm = parts[1];
					break;
				}
			}
		}
		else {
			searchTerm = query;
		}

		addRowsWithSearchTerm(allRows, searchTerm);
		if (searchTerm.length>0) {
			$("#searchtext").val(searchTerm);
			$("#searchtext").select();
		}

		$("#search").submit(function(event) {
			event.preventDefault();
			let searchTerm = this.searchtext.value.trim();

			if (oneColumn) {
				document.location.search = "search=" + searchTerm;
			}
			else {
				if (searchTerm == "") {
					addRowsWithSearchTerm(allRows, "");
				}
				$("#searchtext").select();
			}
		});
		$("#searchtext").on("input", function(event) {
			let $this = $(this);
			let value = $this.val();
			if($this.data("lastval") != value){
				$this.data("lastval", value);
				if (!oneColumn && event.which!=13) {
					let searchTerm = searchtext.value.trim();
					addRowsWithSearchTerm(allRows, searchTerm);
				}
			}
		});
		$("#search").focusin( function(event) {
			searchFocus = true;
			updateSearch();
		});
		$("#search").focusout( function(event) {
			searchFocus = false;
			updateSearch();
		});
		$("#search2").submit(function(event) {
			event.preventDefault();
			let searchTerm = this.searchtext2.value.trim();
			
			if (searchTerm.length > 0) {
				let searchURL = "https://duckduckgo.com/?q="+searchTerm+"+site%3Arickandrandy.com";
				let newWindow = window.open(searchURL);
				
				if (newWindow == null || typeof(newWindow)=='undefined') {
					document.location = searchURL;
				}
			}
			this.reset();
		});

		$("span.keyword").css("cursor", "pointer");

		$("#searchtags").mouseenter(function() {
			mouseInKeywords = true;
		}).mouseleave(function() {
			mouseInKeywords = false;
		}).mousemove(function(event) {
			keyX = event.clientX;
			keyY = event.clientY;
		});
	}, "text");

	$(document).keydown(function(event) {
		function scrolledToBottom() {
			return $(window).scrollTop() + window.innerHeight >= $(document).height()
		}

		let handled = false;

		switch (event.which) {
			case 70:	/* f */
				if (!event.altKey && !event.shiftKey && !event.ctrlKey && event.metaKey) {
					$("#searchtext").focus();
					handled = true;
				} 
				break;
			case 32:	/* spacebar */
				if (!event.altKey && !event.shiftKey && !event.ctrlKey && !event.metaKey && scrolledToBottom()) {
					$("html, body").animate({ scrollTop: 0 }, "slow");
					handled = true;
				} 
				break;
		}

		if (handled) {
			event.preventDefault();
		}
	});
});
